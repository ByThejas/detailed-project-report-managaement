import type { EstimateLine, EstimateSection } from '@/features/preparation/types';
import type { CatalogChildRate, CatalogItem, RateCatalog } from './types';

/**
 * Suggests catalog items for a BOQ line by the words and numbers they share, weighted so that rare words
 * ("drake", "20", "nct") count more than common ones ("kv", "supply"). A suggestion is never applied
 * without review: matching by description cannot be exact.
 */

const STOP = new Set('a an and the of for to in on with without by as per at or from is be are this that all its type suitable including incl etc complete nos no set sets mtrs mtr m each item items supplying supply providing erection'.split(' '));

const RATING_UNITS = new Set(['kv', 'mva', 'kva', 'ka', 'mm', 'sqmm', 'ah', 'kn', 'mt']);

/**
 * Words and numbers of a description. A number with its rating unit also gives a joined token ("20mva",
 * "11kv"), so ratings, the thing that tells one item from the next, weigh more than either part alone.
 */
export function tokens(text: string): string[] {
  const parts = (
    text
      .toLowerCase()
      .replace(/sq\.?\s*mm/g, 'sqmm')
      .replace(/(\d)\s*(kv|mva|kva|ka|mm|sqmm|mt|v|a|ah|w|kn)\b/g, '$1 $2')
      .match(/\d+(?:\.\d+)?|[a-z]+/g) ?? []
  ).filter((t) => !STOP.has(t) && (t.length > 1 || /\d/.test(t)));
  const out: string[] = [];
  parts.forEach((t, i) => {
    out.push(t);
    const next = parts[i + 1];
    if (/^\d/.test(t) && next && RATING_UNITS.has(next)) out.push(`${t}${next}`);
  });
  return out;
}

type UnitKind = 'count' | 'length' | 'km' | 'weight' | 'weightDistance' | 'volume' | 'area' | 'lump' | 'other';

export function unitKind(unit: string): UnitKind {
  const u = unit.toLowerCase().replace(/[^a-z0-9/³²]/g, '');
  if (!u) return 'other';
  if (/^(t\/m|pert\/m|mt\/m)/.test(u)) return 'weightDistance';
  if (/^(no|nos|nos|each|set|sets|stack|stacks|bay|perbay|pair|unit|units|lot)/.test(u) || /^no\(/.test(unit.toLowerCase())) return 'count';
  if (/^(km|routekm|perkm|ckm)/.test(u)) return 'km';
  if (/^(m|mtr|mtrs|rmtr|rm|metre|meter|metres|meters|rmt)$/.test(u)) return 'length';
  if (/^(t|mt|tonne|tonnes|ton|kg)$/.test(u)) return 'weight';
  if (/(m3|m³|cum|cumtr|cubic)/.test(u)) return 'volume';
  if (/(m2|m²|sqm|sqmtr)/.test(u)) return 'area';
  if (/^(ls|lumpsum|job)$/.test(u)) return 'lump';
  return 'other';
}

/** Catalog sheets to search for each BOQ part. */
const SHEETS: Record<EstimateSection, (sheet: string) => boolean> = {
  electrical: (s) => s === 'By code' || s.startsWith('SR-CSR'),
  line: (s) => s === 'By code' || s.startsWith('SR-CSR'),
  civil: (s) => s.includes('Civil') || s.startsWith('utilization'),
  lineCivil: (s) => s.includes('Civil') || s === 'By code',
  dismantling: () => false,
};

export interface RateIndex {
  items: CatalogItem[];
  toks: Set<string>[];
  idf: Map<string, number>;
  /** Weighted size of each item's word set, for the cosine score. */
  norms: number[];
  /** Highest voltage class named in each item, or null. */
  hv: (number | null)[];
}

/** The highest voltage class (kV) named in a text, e.g. "110/11 kV" → 110. Null when none is named. */
export function highestKv(text: string): number | null {
  const found = [...text.toLowerCase().matchAll(/(\d+(?:\.\d+)?)\s*\/?\s*(?:\d+(?:\.\d+)?\s*\/?\s*)*kv\b/g)].map((m) => Number(m[1]));
  return found.length ? Math.max(...found) : null;
}

export function buildIndex(catalog: RateCatalog): RateIndex {
  const items = catalog.items.filter((i) => i.rate !== null && i.rate > 0);
  const toks = items.map((i) => new Set(tokens(`${i.item} ${i.context}`)));
  const df = new Map<string, number>();
  for (const s of toks) for (const t of s) df.set(t, (df.get(t) ?? 0) + 1);
  const idf = new Map<string, number>();
  for (const [t, n] of df) idf.set(t, Math.log(1 + items.length / n));
  const norms = toks.map((s) => Math.sqrt([...s].reduce((sum, t) => sum + idf.get(t)! ** 2, 0)));
  const hv = items.map((i) => highestKv(`${i.item} ${i.context}`));
  return { items, toks, idf, norms, hv };
}

export interface RateSuggestion {
  item: CatalogItem;
  /** 0–1: how alike the line and the item are (cosine of their weighted words). */
  score: number;
  /** Words the line and the item share. */
  shared: number;
  supplyRate: number;
  /** Sum of the item's labour rates in the line's unit. */
  erectionRate: number;
  /** Sum of the item's T&C rates in the line's unit. */
  testingRate: number;
  /** Child rates in another unit (per tonne, per tonne-metre…) that need a quantity basis and were not added. */
  notApplied: CatalogChildRate[];
  /** Per-tonne rates turned into per-No rates from the line's tonnage, in words. */
  converted: string[];
  unitMatches: boolean;
  /** The line names this item by its SoR code. */
  exact?: boolean;
}

/**
 * The basis a unit prices by, finer than its kind: "No", "Set" and "Set (3 Nos.)" are all counts, but a
 * rate per set of three applied per No would be three times too high, so they must not be mixed up.
 * Panels, stacks, bays and pairs count as one No each.
 */
export function unitBasis(unit: string): string {
  const u = unit.toLowerCase().replace(/^\s*per\s+/, '').trim();
  const kind = unitKind(u);
  if (kind !== 'count') return kind;
  const setOf = /^sets?\s*\(\s*(\d+)/.exec(u);
  if (setOf) return `set of ${setOf[1]}`;
  if (/^sets?\b/.test(u)) return 'set';
  return 'no';
}

/** Total tonnage a "No/MT" line carries in its unit, e.g. "No (6.907 MT)" → 6.907. */
export const tonnesOf = (unit: string): number | null => {
  const m = /\((\d+(?:\.\d+)?)\s*MT\)/i.exec(unit);
  return m ? Number(m[1]) : null;
};

const r2 = (n: number) => Math.round(n * 100) / 100;

type LineBasis = Pick<EstimateLine, 'unit' | 'section'> & { qty?: number };

/**
 * Child rates that apply per unit of the line, and those that need another basis. A per-tonne rate is
 * turned into a rate per No when the line carries its tonnage ("No (6.907 MT)"), as KPTCL does for
 * structures and towers (erection Rs/MT × tonnes ÷ number).
 */
function splitChildren(children: CatalogChildRate[], line: LineBasis, itemUnit: string) {
  let total = 0;
  const notApplied: CatalogChildRate[] = [];
  const converted: string[] = [];
  const lb = unitBasis(line.unit);
  const ib = unitBasis(itemUnit);
  const tonnes = tonnesOf(line.unit);
  for (const c of children) {
    const cb = unitBasis(c.unit);
    if (lb !== 'other' && cb === lb) total += c.rate;
    // A child with no readable unit is taken to be in the item's own unit.
    else if (cb === 'other' && lb !== 'other' && lb === ib) total += c.rate;
    else if (cb === 'weight' && lb === 'no' && tonnes && line.qty && line.qty > 0) {
      const perNo = (c.rate * tonnes) / line.qty;
      total += perNo;
      converted.push(`${formatRate(c.rate)} per ${c.unit} × ${tonnes} MT ÷ ${line.qty} = ${formatRate(r2(perNo))} per No`);
    } else notApplied.push(c);
  }
  return { total, notApplied, converted };
}

const formatRate = (n: number) => n.toLocaleString('en-IN', { maximumFractionDigits: 2 });

export function suggestRates(index: RateIndex, line: LineBasis & Pick<EstimateLine, 'description'>, max = 3): RateSuggestion[] {
  const lt = [...new Set(tokens(line.description))];
  if (!lt.length) return [];
  const weight = (t: string) => index.idf.get(t) ?? Math.log(1 + index.items.length);
  const lineHv = highestKv(line.description);
  const lineNorm = Math.sqrt(lt.reduce((s, t) => s + weight(t) ** 2, 0));
  const lu = unitKind(line.unit);
  const allowed = SHEETS[line.section];
  const scored: { i: number; score: number; shared: number }[] = [];
  index.items.forEach((item, i) => {
    if (!allowed(item.sheet)) return;
    const s = index.toks[i]!;
    let dot = 0;
    let shared = 0;
    for (const t of lt)
      if (s.has(t)) {
        dot += weight(t) ** 2;
        shared += 1;
      }
    if (!dot) return;
    // Cosine, softened toward the line's own coverage so long catalog texts are not punished too hard.
    const coverage = dot / lineNorm ** 2;
    const cosine = dot / (lineNorm * index.norms[i]!);
    let score = Math.sqrt(coverage * cosine);
    const iu = unitKind(item.unit);
    if (lu !== 'other' && iu !== 'other' && lu !== iu) score *= 0.7;
    // A different voltage class is a different item (a 66 kV transformer is not a 110 kV one).
    const hv = lineHv;
    const ihv = index.hv[i];
    if (hv !== null && ihv !== null && hv !== ihv) score *= 0.6;
    scored.push({ i, score, shared });
  });
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, max).map(({ i, score, shared }) => suggestionFor(index.items[i]!, line, Math.min(1, score), shared));
}

/** Rates a catalog item gives a BOQ line: supply, plus the labour and T&C rates that are in the line's unit. */
export function suggestionFor(item: CatalogItem, line: LineBasis, score = 1, shared = 0): RateSuggestion {
  const multi = line.section === 'electrical' || line.section === 'line';
  const labour = splitChildren(item.labour, line, item.unit);
  const tc = splitChildren(item.tc, line, item.unit);
  const lb = unitBasis(line.unit);
  const ib = unitBasis(item.unit);
  return {
    item,
    score,
    shared,
    supplyRate: item.rate ?? 0,
    erectionRate: multi ? labour.total : 0,
    testingRate: multi ? tc.total : 0,
    notApplied: multi ? [...labour.notApplied, ...tc.notApplied] : [],
    converted: multi ? [...labour.converted, ...tc.converted] : [],
    unitMatches: lb === 'other' || ib === 'other' || lb === ib,
  };
}

/**
 * The line after taking a catalog suggestion. The catalog's supply rate replaces the line's; its erection
 * and T&C rates replace the line's only when the catalog has one in the line's unit. A catalog with no such
 * rate (none at all, or only per tonne-metre) never wipes out a rate the line already has: that would drop
 * the erection cost from the estimate without anyone noticing.
 */
export function applySuggestion(line: EstimateLine, s: RateSuggestion): { line: EstimateLine; kept: ('erection' | 'testing')[] } {
  const multi = line.section === 'electrical' || line.section === 'line';
  const kept: ('erection' | 'testing')[] = [];
  const pick = (catalog: number, now: number, kind: 'erection' | 'testing') => {
    if (!multi) return 0;
    if (catalog > 0) return catalog;
    if (now > 0) kept.push(kind);
    return now;
  };
  return {
    line: {
      ...line,
      supplyRate: s.supplyRate,
      erectionRate: pick(s.erectionRate, line.erectionRate, 'erection'),
      testingRate: pick(s.testingRate, line.testingRate, 'testing'),
      rateRef: rateRefOf(s),
    },
    kept,
  };
}

/**
 * Work items with no material in them (re-erecting released equipment, testing, excavation, surveys, re-stringing).
 * They carry a labour or T&C rate only, so a catalog match must never give them a supply rate.
 */
export const isLabourOnly = (description: string) =>
  /^\s*(testing|test\b|check survey|excavation|jelly|releas|re-?\s*erect|dismantl|integration of)|re-?\s*erection|released and|releasing and|re-?stringing|stub templates/i.test(description);

/** A match close enough to tick for the user: very close wording, every number in the BOQ line also in the item, same unit. */
export const RELIABLE_SCORE = 0.85;
const numbersOf = (t: string) => t.toLowerCase().match(/\d+(?:\.\d+)?/g) ?? [];
export function isReliable(line: Pick<EstimateLine, 'description'>, s: RateSuggestion): boolean {
  // A fragment such as "For 66kV Line" (the item's name sits in a heading above it) says too little to trust.
  if (s.score < RELIABLE_SCORE || !s.unitMatches || isLabourOnly(line.description) || new Set(tokens(line.description)).size < 4) return false;
  const have = new Set(numbersOf(`${s.item.item} ${s.item.context}`));
  return numbersOf(line.description).every((n) => have.has(n));
}

/** Where a rate came from, shown under the BOQ line. */
export const rateRefOf = (s: RateSuggestion) => `SoR 2023-24 · ${s.item.sheet} ${s.item.code}${s.item.sr ? ` · ${s.item.sr}` : ''}`;

const CIVIL_SHEET = /civil/i;

/**
 * The catalog item a BOQ line names by its own SoR code ("SR Code" column), when there is exactly one
 * such item in the right part of the catalog and its unit agrees. These are the only matches the app
 * ticks for the user; everything matched by wording waits for a tick.
 */
export function exactCodeMatch(index: RateIndex, line: LineBasis & Pick<EstimateLine, 'srCode'>): RateSuggestion | null {
  const code = line.srCode?.trim().replace(/^(sr|sor)\s*/i, '');
  if (!code) return null;
  const civil = line.section === 'civil' || line.section === 'lineCivil';
  const found = index.items.filter((i) => i.code === code && i.rate !== null && SHEETS[line.section](i.sheet) && (!civil || CIVIL_SHEET.test(i.sheet)));
  const item = found.find((i) => i.sheet === 'By code') ?? (found.length === 1 ? found[0] : undefined);
  if (!item) return null;
  const s = suggestionFor(item, line, 1);
  const lb = unitBasis(line.unit);
  return lb !== 'other' && lb === unitBasis(item.unit) ? { ...s, exact: true } : null;
}
