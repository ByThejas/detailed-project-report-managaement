import { createBrowserRouter, Navigate } from 'react-router-dom';
import { AppLayout } from '@/layouts/AppLayout';
import { DashboardPage } from '@/features/dashboard/DashboardPage';
import { InitializationPage } from '@/features/initialization/InitializationPage';
import { ReportsPage } from '@/features/reports/ReportsPage';
import { DocumentsPage } from '@/features/documents/DocumentsPage';
import { DprPreparationPage } from '@/features/preparation/DprPreparationPage';
import { BoqFinancePage } from '@/features/boq-finance/BoqFinancePage';
import { NotFoundPage } from '@/pages/NotFoundPage';

export const routes = [
  {
    element: <AppLayout />,
    children: [
      { index: true, element: <Navigate to="/dashboard" replace /> },
      { path: 'dashboard', element: <DashboardPage /> },
      { path: 'initialization', element: <InitializationPage /> },
      { path: 'reports', element: <ReportsPage /> },
      { path: 'documents', element: <DocumentsPage /> },
      { path: 'preparation', element: <DprPreparationPage /> },
      { path: 'boq-test', element: <BoqFinancePage /> },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
];

export const routerFuture = {
  v7_fetcherPersist: true,
  v7_normalizeFormMethod: true,
  v7_partialHydration: true,
  v7_relativeSplatPath: true,
  v7_skipActionErrorRevalidation: true,
} as const;

export const router = createBrowserRouter(routes, { future: routerFuture });
